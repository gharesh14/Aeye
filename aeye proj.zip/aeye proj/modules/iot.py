import cv2
import urllib.request
import numpy as np
import requests

# Replace with the ESP32-CAM's live feed URL
ESP32_CAM_URL = "http://192.168.168.232/cam-hi.jpg"
ESP32_SERVO_URL = "http://192.168.168.193"  # Replace with your ESP32-Servo IP

# def get_frame():
#     """
#     Fetches a single frame from the ESP32-CAM live feed.
#     """
#     try:
#         img_resp = urllib.request.urlopen(ESP32_CAM_URL)
#         imgnp = np.array(bytearray(img_resp.read()), dtype=np.uint8)
#         frame = cv2.imdecode(imgnp, -1)  # Decode image
#         return frame
#     except Exception as e:
#         print(f"Error fetching frame: {e}")
#         return None

def get_frame():
    """
    Fetches a single frame from the ESP32-CAM live feed using OpenCV.
    """
    cap = cv2.VideoCapture(0) 
    if not cap.isOpened():
        print("Error: Could not open video stream.")
        return None
    
    ret, frame = cap.read()
    cap.release()  # Release the capture device
    
    if not ret:
        print("Error: Failed to capture frame.")
        return None
    
    return frame
    
def set_servo_angle(angle):
    """ 
    Sends a request to the ESP32 to set the servo angle.
    """
    pass
    # url = f"{ESP32_SERVO_URL}/control-servo?angle={angle}"
    # try:
    #     response = requests.get(url)
    #     if response.status_code == 200:
    #         print(f"Servo moved to angle {angle}°")
    #     else:
    #         print(f"Failed to move servo to angle {angle}°. HTTP Status Code: {response.status_code}")
    # except requests.exceptions.RequestException as e:
    #     print(f"Error: {e}")
