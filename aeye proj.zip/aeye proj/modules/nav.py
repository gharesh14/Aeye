import PIL
import google.generativeai as genai
import cv2
import tempfile
from PIL import Image
from modules.iot import get_frame
from modules.voice1 import speak_text,get_voice_input

genai.configure(api_key="AIzaSyDRh_LmTo7-uGxYFbFDj0YRgESsoweYtJQ")

def nav():
    model = genai.GenerativeModel("gemini-1.5-flash")
    frame = get_frame()
        
    if frame is None:
        print("Error: Could not fetch frame from live feed.")
        return None
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        #frame_placeholder.image(frame, channels="RGB", use_container_width=True)
        # Save the captured frame temporarily as an image
    temp_image_path = tempfile.mktemp(suffix=".jpg")
    cv2.imwrite(temp_image_path, frame)
    prompt = "You are a describing agent whose purpose is to give me objects in an evironment which I will use as destination so just list me a set of objects and describe where they are, (do not use special symbols in the output )"
        # Use the generative model to generate the description
    pic = Image.open(temp_image_path)
    model = genai.GenerativeModel("gemini-1.5-flash")
    response = model.generate_content([pic, prompt])
        
        # Output and return the response
    print(response.text) 
    speak_text(response.text)
    # Load the captured image into PIL
    pic = Image.open(temp_image_path)
    speak_text("Select an object to mark as destinations")
    dest=get_voice_input()
    prompt=f"""You are a navigation assistant. You are going to guide me to my destination. make sure to be precise, assume that the image is what I am facing, Destination:{dest}"""
    response = model.generate_content([pic,prompt])
    print(response.text)
    speak_text(response.text)
    return response

