import os
import re
from datetime import datetime
from typing import List
import chromadb
import google.generativeai as genai
from chromadb import Documents, EmbeddingFunction, Embeddings
from pypdf import PdfReader

os.environ["GEMINI_API_KEY"] = "AIzaSyCkwIeU-peYPbgxx13hMRc0iKQhdlS11fk"
genai.configure(api_key="AIzaSyCkwIeU-peYPbgxx13hMRc0iKQhdlS11fk")

class GeminiEmbeddingFunction(EmbeddingFunction):
    def __call__(self, input: Documents) -> Embeddings:
        gemini_api_key = os.getenv("GEMINI_API_KEY")
        if not gemini_api_key:
            raise ValueError("Gemini API Key not provided. Please provide GEMINI_API_KEY as an environment variable")
        genai.configure(api_key=gemini_api_key)
        model = "models/embedding-001"
        title = "Custom query"
        return genai.embed_content(model=model,
                                   content=input,
                                   task_type="retrieval_document",
                                   title=title)["embedding"]

def load_pdf(file_path):
    """Load and extract text from a PDF file."""
    reader = PdfReader(file_path)
    text = ""
    for page in reader.pages:
        text += page.extract_text()
    return text

def split_text(text: str):
    """Split text into chunks based on delimiters."""
    split_text = re.split(r'(\n \n)', text)
    return [i for i in split_text if i != ""]

def create_chroma_db(documents: List, path: str):
    """Create a ChromaDB database with the provided documents."""
    name = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    chroma_client = chromadb.PersistentClient(path=path)
    db = chroma_client.create_collection(name=name, embedding_function=GeminiEmbeddingFunction())

    for i, d in enumerate(documents):
        db.add(documents=d, ids=str(i))

    return db, name

def load_chroma_collection(path, name):
    """Load an existing ChromaDB collection."""
    chroma_client = chromadb.PersistentClient(path=path)
    return chroma_client.get_collection(name=name, embedding_function=GeminiEmbeddingFunction())

def get_relevant_passage(query, db, n_results):
    """Retrieve the most relevant passage from the database."""
    passage = db.query(query_texts=[query], n_results=n_results)['documents'][0]
    return passage

def make_rag_prompt(query, relevant_passage):
    """Generate a prompt for the Generative AI model."""
    escaped = relevant_passage.replace("'", "").replace('"', "").replace("\n", " ")
    prompt = (
        """You are a helpful, friendly, and conversational assistant that answers questions using the reference passage provided below. 
        Your responses should be clear, accessible, and engaging, especially for a non-technical audience. 
        Break down complex concepts into simple terms, using relatable examples where appropriate, and avoid unnecessary jargon. 
        Be concise when possible, but ensure your answers are comprehensive and provide all the necessary context to fully address the question. 
        If the reference passage does not directly relate to the question, you may ignore it or supplement your answer with general knowledge. 
        
        QUESTION: '{query}' 
        PASSAGE: '{escaped}' 
        
        ANSWER:"""
    ).format(query=query, escaped=escaped)

    return prompt

def generate_gemini_answer(prompt):
    """Generate an answer using the Generative AI model."""
    gemini_api_key = os.getenv("GEMINI_API_KEY")
    if not gemini_api_key:
        raise ValueError("Gemini API Key not provided. Please provide GEMINI_API_KEY as an environment variable")
    genai.configure(api_key=gemini_api_key)
    model = genai.GenerativeModel('gemini-pro')
    answer = model.generate_content(prompt)
    return answer.text

def generate_answer(db, query):
    """Generate an answer for the provided query using the database."""
    relevant_text = get_relevant_passage(query, db, n_results=3)
    prompt = make_rag_prompt(query, relevant_passage="".join(relevant_text))
    return generate_gemini_answer(prompt)

# Main Execution Flow
pdf_text = load_pdf(file_path="descriptions.pdf")
chunked_text = split_text(text=pdf_text)

db, name = create_chroma_db(documents=chunked_text, path="C:/Repos/RAG/contents")

# Example Usage
db = load_chroma_collection(path="C:/Repos/RAG/contents", name=name)
answer = generate_answer(db, query="describe haresh appearance")
print(answer)


