from groq import Groq
import cv2
import base64
from modules.iot import get_frame
from voice import speak_text
import time
# Function to encode the image to base64
def encode_image_from_frame(frame, output_path="captured_frame.jpg"):
    """
    Saves the frame and encodes it to base64.
    """
    cv2.imwrite(output_path, frame)  # Save the frame
    with open(output_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode("utf-8")

def ocr():
    # Capture the frame
    frame = get_frame()
    if frame is None:
        print("Failed to capture image.")
    else:
        base64_image = encode_image_from_frame(frame)

        # Initialize Groq client
        client = Groq(api_key="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")

        # Send the image to Groq's Vision Model
        chat_completion = client.chat.completions.create(
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": (
                                "Analyze the image and extract all text. "
                                "i dont need a discription of the image only extract the text from the image "
                                "If no text is detected print no text"
                                "If it contains dates, numbers, or addresses, extract them with proper context."
                            ),
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{base64_image}",
                            },
                        },
                    ],
                }
            ],
            model="llama-3.2-11b-vision-preview",
        )

        # Print extracted text
        print(chat_completion.choices[0].message.content)
        speak_text(chat_completion.choices[0].message.content)
        return chat_completion.choices[0].message.content
