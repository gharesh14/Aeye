from modules.voice1 import get_voice_input, speak_text
from modules.scence_desc import scene_desc
from modules.sensory_search import sensory_search, handle_follow_up_queries
from modules.read_books1 import ocr
from modules.sos import send_sos
from captured_faces.face_add import face_add  # Ensure face_add is properly imported
from modules.nav import nav
from modules.iot import set_servo_angle
def start():
    while True:
        print("Function is triggered")
        speak_text("Start to speak")
        
        while True:
            user_talk = get_voice_input()
            print(user_talk)  # Now returns text
            
            if user_talk:  # Ensure input is valid
                Scene_trigger = ["scene", "describe", "description", "seeing", "see"]
                sensory_trigger = ["sensory", "search", "holding", "buy"]
                ocr_trigger = ["read", "book", "notice", "pamphlet"]
                sos_trigger = ["sos", "emergency", "help"]
                face_trigger = ["face", "recognize", "register"]
                nav_trigger=["navigation","route","navigate","path","show me route","show me"]

                if any(word in user_talk for word in Scene_trigger):
                    set_servo_angle(90)
                    sc = scene_desc()
                    speak_text(sc)
                
                if any(word in user_talk for word in sensory_trigger):
                    a1 = sensory_search()
                    handle_follow_up_queries(a1)
                
                if any(word in user_talk for word in ocr_trigger):
                    set_servo_angle(115)
                    ocr()
                
                if any(word in user_talk for word in sos_trigger):
                    a = send_sos()
                    print(a)
                if any(word in user_talk for word in nav_trigger):
                    set_servo_angle(90)
                    nav()

                if any(word in user_talk for word in face_trigger):
                    set_servo_angle(90)
                    detected_name = face_add()
                    if detected_name:
                        speak_text(f"Face registered as {detected_name}")
                    else:
                        speak_text("Face registration failed.")

                if "exit" in user_talk:
                    speak_text("Exiting now.")
                    return  # Stops the function
                
            else:
                speak_text("No Input")

start()

#     # Initialize Mediapipe Hands
#     cap = cv2.VideoCapture(0)
#     mp_hands = mp.solutions.hands
#     hands = mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7)
#     mp_draw = mp.solutions.drawing_utils

#     # Finger landmark indices (TIP points of fingers)
#     finger_tips = [4, 8, 12, 16, 20]

#     def detect_number(hand_landmarks):
#         """
#         Detect the number (1-5) based on which fingers are raised.
#         """
#         fingers = []
        
#         # Thumb
#         if hand_landmarks.landmark[finger_tips[0]].x < hand_landmarks.landmark[finger_tips[0] - 1].x:
#             fingers.append(1)  # Thumb is up
#         else:
#             fingers.append(0)  # Thumb is down
#         # Other 4 fingers
#         for tip in finger_tips[1:]:
#             if hand_landmarks.landmark[tip].y < hand_landmarks.landmark[tip - 2].y:
#                 fingers.append(1)  # Finger is up
#             else:
#                 fingers.append(0)  # Finger is down
#         return fingers.count(1)  # Count the number of fingers up
#     while True:
#         success, img = cap.read()
#         img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
#         results = hands.process(img_rgb)
#         if results.multi_hand_landmarks:
#             for hand_landmarks in results.multi_hand_landmarks:
#                 mp_draw.draw_landmarks(img, hand_landmarks, mp_hands.HAND_CONNECTIONS)
#                 number = detect_number(hand_landmarks)
                
#                 # Display detected number on the screen
#                 cv2.putText(img, f"Number: {number}", (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 0, 0), 3)
#                 cv2.imshow("Hand Gesture Detection", img)
#                 # Check if the gesture "1" is detected
#                 if number == 1:
#                     cv2.destroyAllWindows()
#                     print("Function is triggered")
#                     speak_text("Start to speak")
#                     while True:
#                         user_talk= get_voice_input()
#                         if user_talk:
#                             user_talk=user_talk.lower()
#                             Scene_trigger = ["scene", "describe", "description", "seeing", "see"]
#                             sensory_trigger = ["sensory", "search", "holding", "buy"]
#                             ocr_trigger=["read","book","notice","pamphlet"]
#                             for word in Scene_trigger:
#                                 if word in user_talk:
#                                     sc=scene_desc()
#                                     speak_text(sc)
#                             for word in sensory_trigger:
#                                 if word in user_talk:
#                                     a1=sensory_search()
#                                     handle_follow_up_queries(a1)
#                             for word in ocr_trigger:
#                                 if word in user_talk:
#                                     ocr()
#                             if "exit" in user_talk:
#                                 break
#                         else:
#                             speak_text("No Input")
#                 if number == 2:
#                     cv2.destroyAllWindows()
#                     a=send_sos()
#                     print(a)
#         if cv2.waitKey(1) & 0xFF == ord('q'):
#             break

#     cv2.destroyAllWindows()
# # Call the function to start detection
# start()
